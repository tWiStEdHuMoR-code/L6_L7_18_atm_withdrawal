import pytest
from atm_withdrawal import withdraw, pin_check, note_breakup

# --- withdraw: each decision True/False ---
def test_simple_withdrawal():
    assert withdraw(5000, 1000, "savings", True) == 4000

def test_unknown_account():
    with pytest.raises(ValueError):
        withdraw(5000, 1000, "salary", True)

def test_amount_zero():
    with pytest.raises(ValueError):
        withdraw(5000, 0, "savings", True)

def test_amount_negative():
    with pytest.raises(ValueError):
        withdraw(5000, -100, "savings", True)

def test_amount_not_multiple_of_100():
    with pytest.raises(ValueError):
        withdraw(5000, 150, "savings", True)

def test_savings_limit_exceeded():
    assert withdraw(90000, 25100, "savings", True) == "limit exceeded"

def test_savings_limit_boundary():
    assert withdraw(30000, 25000, "savings", True) == 5000

def test_current_within_limit():
    assert withdraw(90000, 50000, "current", True) == 40000

def test_current_limit_exceeded():
    assert withdraw(90000, 50100, "current", True) == "limit exceeded"

def test_other_bank_low_fee():
    assert withdraw(5000, 1000, "savings", False) == 3980

def test_other_bank_fee_boundary_10000():
    assert withdraw(20000, 10000, "savings", False) == 9980

def test_other_bank_high_fee():
    assert withdraw(30000, 15000, "savings", False) == 14970

def test_insufficient_funds():
    assert withdraw(500, 1000, "savings", True) == "insufficient funds"

def test_insufficient_due_to_fee():
    assert withdraw(1000, 1000, "savings", False) == "insufficient funds"

def test_exact_balance_with_fee():
    assert withdraw(1020, 1000, "savings", False) == 0

# --- pin_check ---
def test_pin_ok_first_try():
    assert pin_check(1234, 1234, 0) == "ok"

def test_pin_ok_on_last_attempt():
    assert pin_check(1234, 1234, 2) == "ok"

def test_pin_already_blocked():
    assert pin_check(1234, 1234, 3) == "card blocked"

def test_pin_wrong_retry():
    assert pin_check(1111, 1234, 1) == "retry"

def test_pin_wrong_blocks_on_third():
    assert pin_check(1111, 1234, 2) == "card blocked"

# --- note_breakup ---
def test_note_invalid():
    with pytest.raises(ValueError):
        note_breakup(150)

def test_note_zero():
    assert note_breakup(0) == (0, 0, 0)

def test_note_only_100s():
    assert note_breakup(100) == (0, 0, 1)

def test_note_200s_branch_true():
    assert note_breakup(700) == (1, 1, 0)

def test_note_200s_branch_false():
    assert note_breakup(600) == (1, 0, 1)

def test_note_multiple_200s():
    assert note_breakup(400) == (0, 2, 0)