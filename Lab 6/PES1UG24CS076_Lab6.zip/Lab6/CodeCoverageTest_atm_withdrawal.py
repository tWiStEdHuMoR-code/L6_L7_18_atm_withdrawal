import pytest
from atm_withdrawal import withdraw, pin_check, note_breakup

# --- withdraw ---
def test_simple_withdrawal():
    assert withdraw(5000, 1000, "savings", True) == 4000

def test_unknown_account():
    with pytest.raises(ValueError):
        withdraw(5000, 1000, "salary", True)

def test_invalid_amount_zero():
    with pytest.raises(ValueError):
        withdraw(5000, 0, "savings", True)

def test_limit_exceeded():
    assert withdraw(90000, 30000, "savings", True) == "limit exceeded"

def test_other_bank_fee():
    assert withdraw(5000, 1000, "savings", False) == 3980

def test_other_bank_high_fee():
    assert withdraw(30000, 15000, "savings", False) == 14970

def test_insufficient_funds():
    assert withdraw(500, 1000, "savings", True) == "insufficient funds"

# --- pin_check ---
def test_correct_pin():
    assert pin_check(1234, 1234, 0) == "ok"

def test_blocked_by_attempts():
    assert pin_check(1234, 1234, 3) == "card blocked"

def test_wrong_pin_third_attempt():
    assert pin_check(1111, 1234, 2) == "card blocked"

def test_wrong_pin_retry():
    assert pin_check(1111, 1234, 0) == "retry"

# --- note_breakup ---
def test_note_invalid():
    with pytest.raises(ValueError):
        note_breakup(150)

def test_note_with_200s():
    assert note_breakup(1200) == (2, 1, 0)

def test_note_without_200s():
    assert note_breakup(600) == (1, 0, 1)